# Aether - Back-end Mobile em Dart e PostgreSQL

API REST do **Sistema de Gestão Esportiva Escolar**, adaptada aos wireframes Mobile e ao arquivo **Divisão por Dispositivo**.

## Tecnologias

- Dart 3.8+
- Shelf e Shelf Router
- PostgreSQL 16
- JWT
- BCrypt
- Docker Compose

## O que foi implementado

O módulo `/api/mobile` possui 49 operações para:

- autenticação e recuperação de senha;
- dashboard do aplicativo;
- perfil e consulta de escolas;
- cadastro, consulta e edição de atletas;
- histórico, estatísticas e ranking individual;
- cadastro e gerenciamento de times;
- vínculo, função, capitão e escalação de atletas;
- consulta de competições;
- calendário, locais e inscrição de times;
- partidas ao vivo, arbitragem, pontuação e penalidades;
- publicação de resultados;
- rankings de escolas, equipes e atletas;
- tabelas e classificações.

O mapeamento completo está em `MAPEAMENTO_CASOS_MOBILE.md`.

## Executar no VS Code com Docker

Abra esta pasta diretamente no VS Code e execute:

```bash
docker compose down -v
docker compose up
```

O parâmetro `-v` é importante na primeira execução desta versão, pois garante que as novas migrações Mobile sejam aplicadas.

Teste no navegador:

```text
http://localhost:8080/api/mobile/saude
```

## Contas de teste

Todas usam a senha `Admin@123`.

| Perfil | E-mail |
|---|---|
| Administrador | `admin@aether.local` |
| Escola | `escola@aether.local` |
| Aluno/atleta | `atleta@aether.local` |
| Árbitro | `arbitro@aether.local` |

## Endereços para o Flutter

- Android Emulator: `http://10.0.2.2:8080/api/mobile`
- Celular físico: `http://IP_DO_COMPUTADOR:8080/api/mobile`
- Navegador no computador: `http://localhost:8080/api/mobile`

O computador e o celular precisam estar na mesma rede, e a porta 8080 deve estar liberada no firewall.

## Arquivos importantes

- `lib/src/routes/mobile_router.dart`: rotas do aplicativo.
- `lib/src/repositories/escola_repository.dart`: perfil e escolas.
- `lib/src/repositories/time_repository.dart`: times e escalação.
- `lib/src/repositories/mobile_repository.dart`: dashboard, partidas ao vivo e rankings.
- `migrations/003_mobile.sql`: estrutura complementar Mobile.
- `migrations/004_seed_mobile.sql`: dados de demonstração.
- `MOBILE_ENDPOINTS.md`: exemplos de requisições.
- `INTEGRACAO_FLUTTER_MOBILE.md`: cliente Dart para o Flutter.
- `openapi_mobile.yaml`: contrato para Swagger, Postman ou Insomnia.

## Atualização em tempo real

Para o protótipo, a tela de partida ao vivo utiliza **polling**: o Flutter consulta `GET /partidas/{id}/ao-vivo` a cada 2 ou 3 segundos. Isso mantém placar, eventos, arbitragem e publicação atualizados sem exigir um servidor WebSocket adicional.

## Observação sobre os wireframes

Alguns wireframes antigos mostram botões de exclusão ou cadastro de escola. O arquivo **Divisão por Dispositivo** classifica essas operações como exclusivas de PC. Por isso, elas não foram incluídas no módulo `/api/mobile`.

## Execução sem Docker

Instale Dart e PostgreSQL, execute as migrações na ordem `001`, `002`, `003` e `004`, configure `.env.example` e rode:

```bash
dart pub get
dart run bin/server.dart
```

O aplicativo Flutter nunca deve acessar o PostgreSQL diretamente; toda comunicação deve passar pela API HTTP.
