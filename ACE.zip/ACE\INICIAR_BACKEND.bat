@echo off
cd /d "%~dp0backend"
docker compose up
