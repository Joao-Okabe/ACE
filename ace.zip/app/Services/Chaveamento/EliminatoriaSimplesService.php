<?php

class EliminatoriaSimplesService
{
    private PDO $pdo;

    private Competicao $competicaoModel;

    private EtapaCompeticao $etapaCompeticaoModel;

    private RodadaCompeticao $rodadaCompeticaoModel;

    private Confronto $confrontoModel;

    private ConfrontoParticipante $confrontoParticipanteModel;

    private OrigemParticipanteConfronto $origemParticipanteConfrontoModel;

    public function __construct()
    {
        $this->pdo = Database::connect();

        $this->competicaoModel = new Competicao();

        $this->etapaCompeticaoModel = new EtapaCompeticao();

        $this->rodadaCompeticaoModel = new RodadaCompeticao();

        $this->confrontoModel = new Confronto();

        $this->confrontoParticipanteModel = new ConfrontoParticipante();

        $this->origemParticipanteConfrontoModel = new OrigemParticipanteConfronto();
    }
    public function gerar(
        int $cdCompeticao,
        int $cdEtapaCompeticao
    ): void 
    {
        $times = $this->buscarTimes($cdCompeticao);

        $this->validarQuantidadeTimes($times);
        $this->validarEtapa($cdCompeticao, $cdEtapaCompeticao);

        $tamanhoChave = $this->calcularTamanhoChave(
            count($times)
        );

        $seeds = $this->gerarSeeds($tamanhoChave);

        $posicoes = $this->distribuirTimes(
            $times,
            $seeds,
            $tamanhoChave
        );

        $rodadas = $this->criarRodadas(
            $cdEtapaCompeticao,
            $tamanhoChave
        );

        $confrontos = $this->criarPrimeiraRodada(
            $rodadas[0],
            $posicoes
        );

        $this->criarProximasRodadas(
            $rodadas,
            $confrontos
        );
    }

    private function buscarTimes(int $cdCompeticao): array
    {
        return $this->competicaoModel
            ->buscarTimesInscritos($cdCompeticao);
    }

    private function validarQuantidadeTimes(array $times): void
    {
        if (count($times) < 2) {
            throw new RuntimeException(
                'A eliminatória simples precisa de pelo menos 2 times.'
            );
        }
    }

    private function validarEtapa(
        int $cdCompeticao,
        int $cdEtapaCompeticao
    ): void {
        $etapa = $this->etapaCompeticaoModel
            ->buscarPorCompeticao(
                $cdEtapaCompeticao,
                $cdCompeticao
            );

        if (!$etapa) {
            throw new RuntimeException(
                'A etapa não pertence à competição.'
            );
        }

        if ($etapa['nm_tipo_etapa'] !== 'ELIMINATORIA') {
            throw new RuntimeException(
                'A etapa informada não é uma etapa eliminatória.'
            );
        }
    }

    private function calcularTamanhoChave(
        int $quantidadeTimes
    ): int {
        $tamanho = 1;

        while ($tamanho < $quantidadeTimes) {
            $tamanho *= 2;
        }

        return $tamanho;
    }

    private function gerarSeeds(int $tamanho): array
    {
        if ($tamanho === 2) {
            return [1, 2];
        }

        $seeds = [1, 2];

        while (count($seeds) < $tamanho) {
            $limite = count($seeds) * 2 + 1;
            $novosSeeds = [];

            foreach ($seeds as $seed) {
                $novosSeeds[] = $seed;
                $novosSeeds[] = $limite - $seed;
            }

            $seeds = $novosSeeds;
        }

        return $seeds;
    }

    private function distribuirTimes(
        array $times,
        array $seeds,
        int $tamanhoChave
    ): array {
        $posicoes = array_fill(
            0,
            $tamanhoChave,
            null
        );

        foreach ($times as $indice => $time) {
            $posicoes[$indice] = [
                'seed' => $seeds[$indice],
                'cd_time' => $time['cd_time'],
                'nm_time' => $time['nm_time']
            ];
        }

        return $posicoes;
    }

    private function criarRodadas(
        int $cdEtapaCompeticao,
        int $tamanhoChave
    ): array {
        $quantidadeRodadas = (int) log(
            $tamanhoChave,
            2
        );

        $rodadas = [];

        for ($i = 1; $i <= $quantidadeRodadas; $i++) {
            $rodadas[] = $this->rodadaModel->criar([
                'cd_etapa_competicao' => $cdEtapaCompeticao,
                'nr_rodada' => $i,
                'nm_rodada' => $this->nomeRodada(
                    $quantidadeRodadas,
                    $i
                )
            ]);
        }

        return $rodadas;
    }

    private function nomeRodada(
        int $totalRodadas,
        int $rodada
    ): string {
        $distancia = $totalRodadas - $rodada;

        return match ($distancia) {
            0 => 'Final',
            1 => 'Semifinal',
            2 => 'Quartas de final',
            3 => 'Oitavas de final',
            default => "Rodada {$rodada}"
        };
    }

    private function criarPrimeiraRodada(
        int $cdRodada,
        array $posicoes
    ): array {
        $confrontos = [];

        for (
            $i = 0;
            $i < count($posicoes);
            $i += 2
        ) {
            $confronto = $this->confrontoModel->criar([
                'cd_rodada' => $cdRodada,
                'nr_confronto' => ($i / 2) + 1,
                'status' => 'PENDENTE'
            ]);

            $confrontos[] = $confronto;

            $this->adicionarParticipante(
                $confronto,
                1,
                $posicoes[$i]
            );

            $this->adicionarParticipante(
                $confronto,
                2,
                $posicoes[$i + 1]
            );
        }

        return $confrontos;
    }

    private function adicionarParticipante(
        int $cdConfronto,
        int $posicao,
        ?array $time
    ): void {
        if ($time === null) {
            $cdOrigem = $this->origemModel
                ->criarBye();

            $status = 'BYE';
        } else {
            $cdOrigem = $this->origemModel
                ->criarTime($time['cd_time']);

            $status = 'DEFINIDO';
        }

        $this->confrontoParticipanteModel->criar([
            'cd_confronto' => $cdConfronto,
            'posicao' => $posicao,
            'cd_origem_participante' => $cdOrigem,
            'status' => $status
        ]);
    }

    private function criarProximasRodadas(
        array $rodadas,
        array $confrontosAnteriores
    ): void {
        for (
            $indiceRodada = 1;
            $indiceRodada < count($rodadas);
            $indiceRodada++
        ) {
            $novosConfrontos = [];

            for (
                $i = 0;
                $i < count($confrontosAnteriores);
                $i += 2
            ) {
                $confrontoA = $confrontosAnteriores[$i];
                $confrontoB = $confrontosAnteriores[$i + 1];

                $confronto = $this->confrontoModel->criar([
                    'cd_rodada' => $rodadas[$indiceRodada],
                    'nr_confronto' => ($i / 2) + 1,
                    'status' => 'AGUARDANDO'
                ]);

                $novosConfrontos[] = $confronto;

                $this->adicionarOrigemConfronto(
                    $confronto,
                    1,
                    $confrontoA
                );

                $this->adicionarOrigemConfronto(
                    $confronto,
                    2,
                    $confrontoB
                );
            }

            $confrontosAnteriores = $novosConfrontos;
        }
    }

    private function adicionarOrigemConfronto(
        int $cdConfronto,
        int $posicao,
        int $cdConfrontoAnterior
    ): void {
        $cdOrigem = $this->origemModel
            ->criarVencedorConfronto(
                $cdConfrontoAnterior
            );

        $this->confrontoParticipanteModel->criar([
            'cd_confronto' => $cdConfronto,
            'posicao' => $posicao,
            'cd_origem_participante' => $cdOrigem,
            'status' => 'PENDENTE'
        ]);
    }
}